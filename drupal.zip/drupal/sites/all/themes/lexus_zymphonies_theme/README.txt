About Zymphonies Theme
------------------------------
Zymphonies Theme is a very modern and professional Drupal theme that is perfect for all sorts of corporate and small business websites. This theme is not dependent on any core theme. It is very light weight with modern look and feel. Business's clean layout and light weight code make it a great theme for small or medium-sized business to get up and running quickly.

Drupal compatibility:
------------------------------
This theme is compatible with Drupal 7.x.x

Support & Customization:
------------------------------
Email: info@zymphonies.com

Design by:
------------------------------
FreeBiezz - www.freebiezz.com

Developed by:
------------------------------
Zymphonies - www.zymphonies.com