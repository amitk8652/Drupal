<?php
/**
 * @file
 * Esteem theme implementation to display a region.
 */

if (!empty($content)): ?>
<div class="<?php print $classes; ?>">
  <?php print $content; ?>
</div>
<?php endif; ?>
